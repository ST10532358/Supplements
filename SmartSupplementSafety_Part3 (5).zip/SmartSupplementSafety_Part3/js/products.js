/* ==========================================================================
   Smart Supplement Safety - sample data
   --------------------------------------------------------------------------
   This file is the "database" for the prototype. The site is front-end only
   (no server), so product, ingredient and rule data lives here and is loaded
   before js/script.js. All products, prices and stock levels are SAMPLE data
   for a student project - they are not real products.

   To add a product: copy one object in PRODUCTS, give it a new id, and add
   matching images in /images (see "image" below).
   ========================================================================== */

window.SSS_DATA = (function () {
  "use strict";

  /* Product categories shown in the catalogue filter */
  var CATEGORIES = {
    "protein": "Protein",
    "pre-workout": "Pre-Workout",
    "creatine": "Creatine",
    "amino": "Amino Acids",
    "vitamins": "Vitamins & Minerals",
    "recovery": "Recovery",
    "weight": "Weight Management",
    "allergy-friendly": "Allergy-Friendly"
  };

  /* Fitness goals the client can choose on the screening page */
  var GOALS = {
    "muscle-gain": "Muscle gain",
    "strength": "Strength",
    "recovery": "Recovery",
    "weight-management": "Weight management",
    "general-health": "General health"
  };

  /* Allergens and ingredients the screening tool tracks as tick-boxes.
     These words are matched against each product's "contains" and
     "mayContain" lists below. */
  var ALLERGENS = [
    "lactose", "milk", "soy", "gluten", "peanuts", "tree nuts",
    "eggs", "fish", "caffeine", "artificial sweeteners"
  ];

  /* Health situations that trigger a "needs professional review" flag.
     These are simple demonstration rules, NOT medical rules. */
  var RISK_FACTORS = {
    "condition": "a diagnosed health condition",
    "medication": "chronic medication",
    "pregnant": "pregnancy or breastfeeding"
  };

  /* Stock levels (sample) */
  var STOCK = {
    "in-stock": "In stock",
    "low-stock": "Low stock",
    "out-of-stock": "Out of stock"
  };

  /* Fields on each product:
       id          unique id, also used in the enquiry form drop-down
       name        full product name
       short       short label drawn on the generated product illustration
       category    key from CATEGORIES
       goals       keys from GOALS this product is relevant to
       price       sample price in rand
       stock       key from STOCK
       image       file-name stem in /images (e.g. "whey-isolate" uses
                   whey-isolate-400.png, whey-isolate-800.webp, etc.)
       servingSize text only
       desc        short description
       ingredients full ingredient list as printed on the (sample) label
       contains    tracked allergens the product lists as ingredients
       mayContain  tracked allergens possibly present through cross-contact
       caffeineMg  caffeine per serving in mg
       reviewFor   RISK_FACTORS keys that make this product "needs review"
       warnings    label warning text                                     */
  var PRODUCTS = [
    {
      id: "whey-isolate", name: "Grass-Fed Whey Isolate", short: "WHEY ISOLATE",
      category: "protein", goals: ["muscle-gain", "recovery"], price: 649, stock: "in-stock",
      image: "whey-isolate", servingSize: "1 scoop (30 g)",
      desc: "A fast-absorbing whey isolate for post-training recovery, with 27 g of protein per serving.",
      ingredients: ["Whey protein isolate", "Sunflower lecithin", "Natural flavouring", "Stevia leaf extract", "Xanthan gum"],
      contains: ["milk", "lactose"], mayContain: ["soy"], caffeineMg: 0, reviewFor: [],
      warnings: "Not intended for children. Contains milk-derived ingredients."
    },
    {
      id: "plant-protein", name: "Plant Protein Blend", short: "PLANT PROTEIN",
      category: "protein", goals: ["muscle-gain", "general-health"], price: 589, stock: "in-stock",
      image: "plant-protein", servingSize: "1 scoop (34 g)",
      desc: "A pea, rice and hemp protein blend for dairy-free, plant-based muscle support.",
      ingredients: ["Pea protein isolate", "Brown rice protein", "Hemp protein", "Natural cocoa flavouring", "Monk fruit extract"],
      contains: [], mayContain: ["tree nuts"], caffeineMg: 0, reviewFor: [],
      warnings: "Made in a facility that also processes tree nuts."
    },
    {
      id: "clear-whey", name: "Clear Whey Isolate - Citrus", short: "CLEAR WHEY",
      category: "protein", goals: ["muscle-gain", "recovery"], price: 679, stock: "low-stock",
      image: "clear-whey", servingSize: "1 scoop (25 g)",
      desc: "A light, juice-style protein isolate for people who do not want a heavy shake after training.",
      ingredients: ["Hydrolysed whey protein isolate", "Citric acid", "Natural citrus flavouring", "Sucralose", "Beta-carotene (colour)"],
      contains: ["milk", "lactose", "artificial sweeteners"], mayContain: [], caffeineMg: 0, reviewFor: [],
      warnings: "Contains an artificial sweetener (sucralose)."
    },
    {
      id: "ignite-pre-workout", name: "Ignite Pre-Workout", short: "IGNITE",
      category: "pre-workout", goals: ["strength", "muscle-gain"], price: 459, stock: "in-stock",
      image: "ignite-pre-workout", servingSize: "1 scoop (10 g)",
      desc: "A high-stimulant pre-workout for focus and energy in demanding sessions.",
      ingredients: ["Caffeine anhydrous (200 mg)", "Beta-alanine", "L-citrulline malate", "Artificial flavouring", "FD&C Red 40 (colour)", "Sucralose"],
      contains: ["caffeine", "artificial colours", "artificial sweeteners"], mayContain: [], caffeineMg: 200,
      reviewFor: ["condition", "medication", "pregnant"],
      warnings: "High caffeine content. Not for use within six hours of sleep or if you are sensitive to stimulants."
    },
    {
      id: "zero-stim-pre-workout", name: "Zero Stim Pre-Workout", short: "ZERO STIM",
      category: "pre-workout", goals: ["strength", "muscle-gain"], price: 429, stock: "in-stock",
      image: "zero-stim-pre-workout", servingSize: "1 scoop (12 g)",
      desc: "A caffeine-free pre-workout built on citrulline and beta-alanine for pump and endurance.",
      ingredients: ["L-citrulline malate", "Beta-alanine", "Betaine anhydrous", "Natural watermelon flavouring", "Stevia leaf extract"],
      contains: [], mayContain: [], caffeineMg: 0, reviewFor: [],
      warnings: "Beta-alanine may cause a temporary tingling sensation."
    },
    {
      id: "creatine-monohydrate", name: "Creatine Monohydrate", short: "CREATINE",
      category: "creatine", goals: ["strength", "muscle-gain"], price: 339, stock: "in-stock",
      image: "creatine-monohydrate", servingSize: "1 level scoop (5 g)",
      desc: "Micronised, unflavoured creatine monohydrate for strength, power and lean mass.",
      ingredients: ["Creatine monohydrate (micronised)"],
      contains: [], mayContain: [], caffeineMg: 0, reviewFor: ["condition", "medication"],
      warnings: "Drink plenty of water. Speak to a healthcare professional first if you have a kidney condition."
    },
    {
      id: "creatine-electrolyte", name: "Creatine + Electrolyte Blend", short: "CREATINE+",
      category: "creatine", goals: ["strength"], price: 389, stock: "out-of-stock",
      image: "creatine-electrolyte", servingSize: "1 scoop (8 g)",
      desc: "Creatine monohydrate with sodium, potassium and magnesium for training-day hydration.",
      ingredients: ["Creatine monohydrate", "Sodium citrate", "Potassium chloride", "Magnesium citrate", "Natural lime flavouring"],
      contains: [], mayContain: [], caffeineMg: 0, reviewFor: ["condition", "medication"],
      warnings: "Speak to a healthcare professional first if you have a kidney condition or a sodium-restricted diet."
    },
    {
      id: "eaa-recovery", name: "EAA Recovery Complex", short: "EAA RECOVERY",
      category: "amino", goals: ["recovery", "muscle-gain"], price: 479, stock: "in-stock",
      image: "eaa-recovery", servingSize: "1 scoop (13 g)",
      desc: "A full essential amino acid profile to support recovery between sessions.",
      ingredients: ["Essential amino acid blend", "Coconut water powder", "Natural berry flavouring", "Beetroot juice powder (colour)"],
      contains: [], mayContain: ["tree nuts"], caffeineMg: 0, reviewFor: [],
      warnings: "Made in a facility that also processes tree nuts."
    },
    {
      id: "daily-multivitamin", name: "Daily Multivitamin - Active", short: "MULTIVITAMIN",
      category: "vitamins", goals: ["general-health"], price: 249, stock: "in-stock",
      image: "daily-multivitamin", servingSize: "2 tablets", shape: "bottle",
      desc: "A daily multivitamin for regular trainers, with added B-vitamins and zinc.",
      ingredients: ["Vitamin C", "Vitamin D3", "B-complex vitamins", "Zinc citrate", "Magnesium oxide", "Microcrystalline cellulose"],
      contains: [], mayContain: ["soy"], caffeineMg: 0, reviewFor: ["medication", "pregnant"],
      warnings: "Contains zinc. Do not combine with other zinc supplements without advice."
    },
    {
      id: "omega-3-fish-oil", name: "Omega-3 Fish Oil", short: "OMEGA-3",
      category: "vitamins", goals: ["general-health", "recovery"], price: 299, stock: "in-stock",
      image: "omega-3-fish-oil", servingSize: "2 softgels", shape: "bottle",
      desc: "A concentrated EPA/DHA fish oil to support joint and heart health.",
      ingredients: ["Fish oil concentrate (anchovy, sardine)", "Gelatin capsule", "Vitamin E (antioxidant)"],
      contains: ["fish"], mayContain: [], caffeineMg: 0, reviewFor: ["condition", "medication", "pregnant"],
      warnings: "Not suitable for people with a fish allergy. Speak to a doctor first if you take blood-thinning medication."
    },
    {
      id: "magnesium-recovery", name: "Magnesium Recovery Complex", short: "MAGNESIUM",
      category: "recovery", goals: ["recovery", "general-health"], price: 279, stock: "in-stock",
      image: "magnesium-recovery", servingSize: "3 capsules", shape: "bottle",
      desc: "A magnesium blend to support muscle relaxation and sleep quality after heavy training.",
      ingredients: ["Magnesium bisglycinate", "Magnesium citrate", "Vegetable capsule (HPMC)"],
      contains: [], mayContain: [], caffeineMg: 0, reviewFor: ["condition", "medication"],
      warnings: "May have a mild laxative effect at higher doses."
    },
    {
      id: "lean-support", name: "Lean Support Capsules", short: "LEAN SUPPORT",
      category: "weight", goals: ["weight-management"], price: 389, stock: "low-stock",
      image: "lean-support", servingSize: "2 capsules", shape: "bottle",
      desc: "A green tea extract and chromium formula to support a calorie-controlled training plan.",
      ingredients: ["Green tea extract", "Chromium picolinate", "L-carnitine tartrate", "Vegetable capsule", "Caffeine anhydrous (90 mg)"],
      contains: ["caffeine"], mayContain: [], caffeineMg: 90, reviewFor: ["condition", "medication", "pregnant"],
      warnings: "Contains caffeine. Not a replacement for a calorie-controlled diet and exercise."
    },
    {
      id: "meal-replacement-shake", name: "Meal Replacement Shake", short: "MEAL SHAKE",
      category: "weight", goals: ["weight-management"], price: 399, stock: "in-stock",
      image: "meal-replacement-shake", servingSize: "2 scoops (60 g)",
      desc: "A balanced macro shake for a structured, calorie-controlled meal replacement.",
      ingredients: ["Milk protein concentrate", "Oat flour", "Sunflower oil", "Vitamin & mineral blend", "Natural vanilla flavouring"],
      contains: ["milk", "lactose"], mayContain: ["gluten", "soy"], caffeineMg: 0, reviewFor: ["condition", "pregnant"],
      warnings: "Not for pregnant or breastfeeding women, or children, without medical advice."
    },
    {
      id: "free-from-protein", name: "Free-From Protein - Vegan & Gluten-Free", short: "FREE-FROM",
      category: "allergy-friendly", goals: ["muscle-gain", "general-health"], price: 619, stock: "in-stock",
      image: "free-from-protein", servingSize: "1 scoop (32 g)",
      desc: "Built for the most common restrictions: no dairy, gluten or soy listed.",
      ingredients: ["Pea protein isolate", "Pumpkin seed protein", "Natural vanilla flavouring", "Monk fruit extract"],
      contains: [], mayContain: [], caffeineMg: 0, reviewFor: [],
      warnings: "Made on a dedicated allergen-controlled line. Always check the current label."
    },
    {
      id: "sensitive-stomach-creatine", name: "Sensitive Stomach Creatine", short: "GENTLE CREATINE",
      category: "allergy-friendly", goals: ["strength"], price: 359, stock: "in-stock",
      image: "sensitive-stomach-creatine", servingSize: "1 scoop (5 g)",
      desc: "Buffered creatine formulated to reduce the bloating some people get with standard monohydrate.",
      ingredients: ["Buffered creatine (magnesium creatine chelate)"],
      contains: [], mayContain: [], caffeineMg: 0, reviewFor: ["condition", "medication"],
      warnings: "Drink plenty of water. Speak to a healthcare professional first if you have a kidney condition."
    }
  ];

  return {
    CATEGORIES: CATEGORIES,
    GOALS: GOALS,
    ALLERGENS: ALLERGENS,
    RISK_FACTORS: RISK_FACTORS,
    STOCK: STOCK,
    PRODUCTS: PRODUCTS
  };
})();
