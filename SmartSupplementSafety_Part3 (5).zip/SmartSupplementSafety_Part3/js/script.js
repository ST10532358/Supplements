/* ==========================================================================
   Smart Supplement Safety - main script (Part 3)
   --------------------------------------------------------------------------
   Vanilla JavaScript, no frameworks. Loaded with "defer" on every page after
   js/products.js (which provides window.SSS_DATA). Each feature starts only
   if its page elements exist, so one file serves all six pages.

   Contents
     1.  Helpers
     2.  Mobile navigation
     3.  Accordion (FAQ)
     4.  Tabs (About page)
     5.  Scroll reveal animation
     6.  Dialog helper (modals)
     7.  Catalogue: render, search, filter, sort, details, lightbox
     8.  Screening engine, results and history
     9.  Form validation helpers
     10. Enquiry form (validation, AJAX, instant response)
     11. Contact form (validation, AJAX, email compile)
     12. Interactive map (Leaflet)
   ========================================================================== */
(function () {
  "use strict";

  var DATA = window.SSS_DATA || { PRODUCTS: [], CATEGORIES: {}, GOALS: {}, ALLERGENS: [], RISK_FACTORS: {}, STOCK: {} };
  var PRODUCTS = DATA.PRODUCTS;
  var CONTACT_RECIPIENT = "support@smartsupplementsafety.example"; /* change to a real address before going live */
  var REDUCED_MOTION = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------------------------------------------------------- 1. Helpers */
  /* Builds elements with textContent only, so user input can never become HTML. */
  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === "text") { node.textContent = attrs[k]; }
        else if (k === "class") { node.className = attrs[k]; }
        else { node.setAttribute(k, attrs[k]); }
      });
    }
    (children || []).forEach(function (c) {
      if (c === null || c === undefined) { return; }
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function clear(node) { while (node.firstChild) { node.removeChild(node.firstChild); } }
  function rand(n) { return "R" + n.toLocaleString("en-ZA"); }
  function label(map, key) { return map[key] || key; }
  function titleCase(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
  function imgFor(p, size) { return "images/" + p.image + "-" + size; }

  function pictureFor(p, size, alt, extra) {
    var pic = el("picture");
    pic.appendChild(el("source", { type: "image/webp", srcset: imgFor(p, 400) + ".webp 400w, " + imgFor(p, 800) + ".webp 800w", sizes: size }));
    var img = el("img", {
      src: imgFor(p, 400) + ".png",
      srcset: imgFor(p, 400) + ".png 400w, " + imgFor(p, 800) + ".png 800w",
      sizes: size, width: "400", height: "300", alt: alt, loading: "lazy"
    });
    pic.appendChild(img);
    return pic;
  }

  function storageGet(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } }
  function storageSet(key, val) { try { window.localStorage.setItem(key, val); } catch (e) { /* storage blocked: ignore */ } }
  function storageRemove(key) { try { window.localStorage.removeItem(key); } catch (e) { /* ignore */ } }

  /* ---------------------------------------------------------------- 2. Mobile navigation */
  function initNav() {
    var toggle = $("#nav-toggle"), nav = $("#site-nav");
    if (!toggle || !nav) { return; }
    document.documentElement.classList.add("nav-ready");
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.textContent = open ? "Close" : "Menu";
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("is-open")) {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.textContent = "Menu";
        toggle.focus();
      }
    });
  }

  /* ---------------------------------------------------------------- 3. Accordion */
  /* Markup: <h3 class="accordion-heading">Question</h3><div>Answer</div> pairs.
     Each heading becomes a button controlling the answer panel. */
  function initAccordions() {
    $$("[data-accordion]").forEach(function (acc, a) {
      var heads = $$(".accordion-heading", acc);
      var items = [];
      heads.forEach(function (h, i) {
        var panel = h.nextElementSibling;
        var text = h.textContent;
        var id = "acc-" + a + "-" + i;
        var btn = el("button", { type: "button", class: "accordion-trigger", id: id + "-btn", "aria-expanded": "false", "aria-controls": id }, [text]);
        clear(h);
        h.appendChild(btn);
        panel.classList.add("accordion-panel");
        panel.id = id;
        panel.setAttribute("role", "region");
        panel.setAttribute("aria-labelledby", id + "-btn");
        panel.hidden = true;
        var wrap = el("div", { class: "accordion-item" });
        h.parentNode.insertBefore(wrap, h);
        wrap.appendChild(h);
        wrap.appendChild(panel);
        items.push(btn);
        btn.addEventListener("click", function () {
          var open = btn.getAttribute("aria-expanded") === "true";
          btn.setAttribute("aria-expanded", String(!open));
          panel.hidden = open;
        });
        btn.addEventListener("keydown", function (e) {
          var idx = items.indexOf(btn);
          if (e.key === "ArrowDown") { e.preventDefault(); items[(idx + 1) % items.length].focus(); }
          if (e.key === "ArrowUp") { e.preventDefault(); items[(idx - 1 + items.length) % items.length].focus(); }
        });
      });
      /* open the first answer so the pattern is obvious */
      if (items[0]) { items[0].click(); }
    });
  }

  /* ---------------------------------------------------------------- 4. Tabs */
  function initTabs() {
    $$("[data-tabs]").forEach(function (box, t) {
      var panels = $$(".tab-panel", box);
      if (!panels.length) { return; }
      var list = el("div", { class: "tablist", role: "tablist", "aria-label": "About sections" });
      var tabs = [];
      function select(i, focus) {
        tabs.forEach(function (tab, j) {
          var on = i === j;
          tab.setAttribute("aria-selected", String(on));
          tab.tabIndex = on ? 0 : -1;
          panels[j].hidden = !on;
        });
        if (focus) { tabs[i].focus(); }
      }
      panels.forEach(function (panel, i) {
        var id = "tab-" + t + "-" + i;
        panel.id = id + "-panel";
        panel.setAttribute("role", "tabpanel");
        panel.setAttribute("aria-labelledby", id);
        var tab = el("button", { type: "button", class: "tab", role: "tab", id: id, "aria-controls": id + "-panel", "aria-selected": "false" }, [panel.getAttribute("data-tab-title")]);
        tab.addEventListener("click", function () { select(i, false); });
        tab.addEventListener("keydown", function (e) {
          var n = tabs.length, to = null;
          if (e.key === "ArrowRight") { to = (i + 1) % n; }
          if (e.key === "ArrowLeft") { to = (i - 1 + n) % n; }
          if (e.key === "Home") { to = 0; }
          if (e.key === "End") { to = n - 1; }
          if (to !== null) { e.preventDefault(); select(to, true); }
        });
        tabs.push(tab);
        list.appendChild(tab);
      });
      box.insertBefore(list, box.firstChild);
      box.classList.add("tabs-ready");
      select(0, false);
    });
  }

  /* ---------------------------------------------------------------- 5. Scroll reveal */
  function initReveal() {
    var items = $$(".reveal");
    if (!items.length || REDUCED_MOTION || !("IntersectionObserver" in window)) { return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.remove("reveal-pending"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    items.forEach(function (it) {
      if (it.getBoundingClientRect().top > window.innerHeight) { it.classList.add("reveal-pending"); }
      io.observe(it);
    });
  }

  /* ---------------------------------------------------------------- 6. Dialog helper */
  var lastTrigger = null;
  function openDialog(d, trigger) {
    lastTrigger = trigger || document.activeElement;
    if (typeof d.showModal === "function") { d.showModal(); } else { d.setAttribute("open", ""); }
  }
  function closeDialog(d) {
    if (typeof d.close === "function") { d.close(); } else { d.removeAttribute("open"); }
  }
  function initDialogs() {
    $$("dialog").forEach(function (d) {
      $$("[data-close]", d).forEach(function (b) { b.addEventListener("click", function () { closeDialog(d); }); });
      /* clicking the dark backdrop closes the dialog */
      d.addEventListener("click", function (e) { if (e.target === d) { closeDialog(d); } });
      d.addEventListener("close", function () { if (lastTrigger && document.contains(lastTrigger)) { lastTrigger.focus(); } });
    });
  }

  /* ---------------------------------------------------------------- 7. Catalogue */
  function stockBadge(p) {
    var cls = p.stock === "in-stock" ? "badge--match" : (p.stock === "low-stock" ? "badge--caution" : "badge--avoid");
    return el("span", { class: "badge " + cls, text: label(DATA.STOCK, p.stock) });
  }

  function initCatalogue() {
    var grid = $("#product-grid");
    if (!grid) { return; }
    var search = $("#catalogue-search"), cat = $("#filter-category"), goal = $("#filter-goal"),
        hide = $("#filter-hide"), sort = $("#filter-sort"), count = $("#result-count"),
        reset = $("#reset-filters"), form = $("#catalogue-toolbar");
    var shown = [];   /* products currently displayed, used by the lightbox */

    Object.keys(DATA.CATEGORIES).forEach(function (k) { cat.appendChild(el("option", { value: k, text: DATA.CATEGORIES[k] })); });
    Object.keys(DATA.GOALS).forEach(function (k) { goal.appendChild(el("option", { value: k, text: DATA.GOALS[k] })); });
    DATA.ALLERGENS.forEach(function (a) { hide.appendChild(el("option", { value: a, text: titleCase(a) })); });
    form.addEventListener("submit", function (e) { e.preventDefault(); });

    function matches(p) {
      var q = search.value.trim().toLowerCase();
      if (q) {
        var hay = [p.name, p.desc, label(DATA.CATEGORIES, p.category), p.ingredients.join(" ")].join(" ").toLowerCase();
        if (hay.indexOf(q) === -1) { return false; }
      }
      if (cat.value && p.category !== cat.value) { return false; }
      if (goal.value && p.goals.indexOf(goal.value) === -1) { return false; }
      if (hide.value && (p.contains.indexOf(hide.value) !== -1 || p.mayContain.indexOf(hide.value) !== -1)) { return false; }
      return true;
    }

    function render() {
      shown = PRODUCTS.filter(matches);
      var s = sort.value;
      shown.sort(function (a, b) {
        if (s === "price-asc") { return a.price - b.price; }
        if (s === "price-desc") { return b.price - a.price; }
        return a.name.localeCompare(b.name);
      });
      clear(grid);
      count.textContent = shown.length === 0 ? "No products match." :
        "Showing " + shown.length + " of " + PRODUCTS.length + " products";
      if (!shown.length) {
        grid.appendChild(el("div", { class: "empty-state" }, [
          el("h2", { text: "No products found" }),
          el("p", { text: "Try a different search word or reset the filters." })
        ]));
        return;
      }
      shown.forEach(function (p, i) { grid.appendChild(card(p, i)); });
    }

    function card(p, index) {
      var imgBtn = el("button", { type: "button", class: "product-image", "aria-label": "Enlarge picture of " + p.name }, [
        pictureFor(p, "(min-width: 64em) 22vw, (min-width: 40em) 45vw, 90vw", p.name + " supplement tub")
      ]);
      imgBtn.addEventListener("click", function () { openLightbox(index, imgBtn); });

      var chips = el("ul", { class: "chips", "aria-label": "Allergens" });
      if (p.contains.length) {
        p.contains.forEach(function (c) { chips.appendChild(el("li", { class: "chip", text: "Contains " + c })); });
      } else {
        chips.appendChild(el("li", { class: "chip", text: "No tracked allergens" }));
      }
      var more = el("button", { type: "button", class: "btn btn--ghost btn--small" }, ["View details"]);
      more.addEventListener("click", function () { openDetails(p, more); });

      var body = el("div", { class: "product-body" }, [
        el("p", { class: "product-meta", text: label(DATA.CATEGORIES, p.category) }),
        el("h3", { text: p.name }),
        el("p", { text: p.desc }),
        chips,
        p.reviewFor.length ? el("p", null, [el("span", { class: "badge badge--review", text: "Review advised" })]) : null,
        el("div", { class: "price-row" }, [el("span", { class: "price", text: rand(p.price) }), stockBadge(p)]),
        more
      ]);
      return el("article", { class: "product-card" }, [imgBtn, body]);
    }

    /* Details modal */
    var detail = $("#detail-dialog"), detailBox = $("#detail-content");
    function section(title, content) {
      return el("div", { class: "detail-section" }, [el("h3", { text: title }), content]);
    }
    function listOf(items) {
      var ul = el("ul");
      items.forEach(function (i) { ul.appendChild(el("li", { text: i })); });
      return ul;
    }
    function openDetails(p, trigger) {
      clear(detailBox);
      var left = el("div", { class: "detail-image" }, [
        (function () { var pic = pictureFor(p, "(min-width: 40em) 22rem, 90vw", p.name + " supplement tub"); pic.querySelector("img").removeAttribute("loading"); return pic; })()
      ]);
      var right = el("div", { class: "dialog-body" }, [
        el("p", { class: "product-meta", text: label(DATA.CATEGORIES, p.category) }),
        el("h2", { id: "detail-title", text: p.name }),
        el("p", null, [el("strong", { text: rand(p.price) }), " per tub, ", stockBadge(p)]),
        section("About", el("p", { text: p.desc + " Serving size: " + p.servingSize + "." })),
        section("Ingredients", el("p", { text: p.ingredients.join(", ") + "." })),
        section("Contains", p.contains.length ? listOf(p.contains.map(titleCase)) : el("p", { text: "None of the tracked allergens." })),
        section("May contain (cross-contact)", p.mayContain.length ? listOf(p.mayContain.map(titleCase)) : el("p", { text: "None listed." })),
        p.caffeineMg ? section("Caffeine", el("p", { text: p.caffeineMg + " mg per serving." })) : null,
        section("Label warnings", el("p", { text: p.warnings })),
        p.reviewFor.length ? el("p", { class: "callout callout--caution" }, [
          "Review advised if you have: " + p.reviewFor.map(function (r) { return label(DATA.RISK_FACTORS, r); }).join(", ") + ". ",
          el("a", { href: "enquiry.html" }, ["Ask a question"])
        ]) : null
      ]);
      detailBox.appendChild(el("div", { class: "detail-grid" }, [left, right]));
      detail.setAttribute("aria-labelledby", "detail-title");
      openDialog(detail, trigger);
    }

    /* Lightbox gallery with previous / next */
    var lb = $("#lightbox"), lbImg = $("#lightbox-img"), lbCap = $("#lightbox-caption"), current = 0;
    function showLightbox(i) {
      if (!shown.length) { return; }
      current = (i + shown.length) % shown.length;
      var p = shown[current];
      lbImg.src = imgFor(p, 800) + ".png";
      lbImg.alt = p.name + " supplement tub";
      lbCap.textContent = p.name + " (" + (current + 1) + " of " + shown.length + ")";
    }
    function openLightbox(i, trigger) { showLightbox(i); openDialog(lb, trigger); }
    $("#lightbox-prev").addEventListener("click", function () { showLightbox(current - 1); });
    $("#lightbox-next").addEventListener("click", function () { showLightbox(current + 1); });
    lb.addEventListener("keydown", function (e) {
      if (e.key === "ArrowLeft") { showLightbox(current - 1); }
      if (e.key === "ArrowRight") { showLightbox(current + 1); }
    });

    [search, cat, goal, hide, sort].forEach(function (c) { c.addEventListener("input", render); });
    reset.addEventListener("click", function () {
      form.reset();
      render();
      search.focus();
    });
    render();
  }

  /* ---------------------------------------------------------------- 8. Screening */
  /* Rules (documented in the README):
       declared allergy found in "contains"            -> avoid
       health factor matches product "reviewFor"       -> review
       declared allergy found in "mayContain"          -> caution
       goal matches and nothing above                  -> match
       otherwise                                       -> other (no conflict, different goal)
     "Other ingredient" text is also searched inside each ingredient list.   */
  function evaluate(p, profile) {
    var reasons = [], status = "other";
    var avoidHit = [], cautionHit = [], reviewHit = [];

    profile.avoid.forEach(function (term) {
      if (p.contains.indexOf(term) !== -1) { avoidHit.push(term); }
      else if (term === "caffeine" && p.caffeineMg > 0) { avoidHit.push("caffeine"); }
      else if (p.mayContain.indexOf(term) !== -1) { cautionHit.push(term); }
      else if (profile.otherTerm && term === profile.otherTerm) {
        var inList = p.ingredients.join(" ").toLowerCase().indexOf(term) !== -1;
        if (inList) { avoidHit.push(term); }
      }
    });
    profile.risks.forEach(function (r) { if (p.reviewFor.indexOf(r) !== -1) { reviewHit.push(r); } });

    avoidHit.forEach(function (t) { reasons.push("Contains " + t + ", which you said you avoid."); });
    reviewHit.forEach(function (r) { reasons.push("A professional should review this because of " + label(DATA.RISK_FACTORS, r) + "."); });
    cautionHit.forEach(function (t) { reasons.push("May contain traces of " + t + " (cross-contact)."); });

    if (avoidHit.length) { status = "avoid"; }
    else if (reviewHit.length) { status = "review"; }
    else if (cautionHit.length) { status = "caution"; }
    else if (p.goals.indexOf(profile.goal) !== -1) { status = "match"; reasons.push("No conflict found, and it supports your goal of " + label(DATA.GOALS, profile.goal).toLowerCase() + "."); }
    else { reasons.push("No conflict found, but it is not aimed at your goal."); }
    return { product: p, status: status, reasons: reasons };
  }

  var GROUPS = [
    ["match", "Potential matches", "badge--match", "Potential match"],
    ["review", "Needs professional review", "badge--review", "Needs professional review"],
    ["caution", "Use with caution", "badge--caution", "Caution"],
    ["avoid", "Contains an ingredient you avoid", "badge--avoid", "Avoid"],
    ["other", "Other products with no conflict", "badge--neutral", "No conflict"]
  ];

  function initScreening() {
    var form = $("#screening-form");
    if (!form) { return; }
    var status = $("#screening-status"), results = $("#screening-results"),
        section = $("#results-section"), heading = $("#results-heading"),
        historyList = $("#history-list"), clearBtn = $("#clear-history"),
        goalError = $("#goal-error"), review = $("#review-dialog"), reviewText = $("#review-text");
    var HKEY = "sss-history";

    function readHistory() {
      try { var h = JSON.parse(storageGet(HKEY) || "[]"); return Array.isArray(h) ? h : []; } catch (e) { return []; }
    }
    function renderHistory() {
      clear(historyList);
      var h = readHistory();
      if (!h.length) { historyList.appendChild(el("li", { text: "No checks yet." })); return; }
      h.forEach(function (item) {
        historyList.appendChild(el("li", null, [
          el("strong", { text: label(DATA.GOALS, item.goal) }),
          " - " + item.matches + " matches, " + item.avoid + " to avoid, " + item.review + " for review",
          el("br"),
          el("span", { class: "hint", text: item.when })
        ]));
      });
    }
    function saveHistory(profile, counts) {
      var h = readHistory();
      h.unshift({ goal: profile.goal, matches: counts.match, avoid: counts.avoid, review: counts.review,
                  when: new Date().toLocaleString("en-ZA") });
      storageSet(HKEY, JSON.stringify(h.slice(0, 5)));
      renderHistory();
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      goalError.textContent = ""; goalError.classList.remove("is-visible");
      status.textContent = ""; status.className = "form-status";

      var goal = (form.querySelector('input[name="goal"]:checked') || {}).value;
      if (!goal) {
        goalError.textContent = "Please choose your fitness goal so we can screen the catalogue.";
        goalError.classList.add("is-visible");
        status.textContent = "We need your fitness goal before we can check anything.";
        status.classList.add("form-status--error");
        form.querySelector('input[name="goal"]').focus();
        return;
      }
      var avoid = $$('input[name="allergies"]:checked', form).map(function (c) { return c.value; });
      var other = $("#allergy-other").value.trim().toLowerCase().slice(0, 60);
      if (other) { avoid.push(other); }
      var risks = $$('input[name="risk"]:checked', form).map(function (c) { return c.value; });
      var profile = { goal: goal, avoid: avoid, risks: risks, otherTerm: other };

      var evaluated = PRODUCTS.map(function (p) { return evaluate(p, profile); });
      var counts = { match: 0, review: 0, caution: 0, avoid: 0, other: 0 };
      evaluated.forEach(function (r) { counts[r.status] += 1; });
      renderResults(evaluated, counts, profile);
      saveHistory(profile, counts);
    });

    form.addEventListener("reset", function () {
      goalError.textContent = ""; goalError.classList.remove("is-visible");
      status.textContent = ""; status.className = "form-status";
      section.hidden = true;
      clear(results);
    });

    clearBtn.addEventListener("click", function () { storageRemove(HKEY); renderHistory(); });

    function renderResults(evaluated, counts, profile) {
      clear(results);
      var summary = el("div", { class: "result-summary" }, [
        el("h3", { text: "Summary for " + label(DATA.GOALS, profile.goal).toLowerCase() }),
        el("p", { text: counts.match + " potential matches, " + counts.review + " needing professional review, " +
          counts.caution + " with a caution, " + counts.avoid + " to avoid." }),
        profile.avoid.length ? el("p", { class: "hint", text: "Avoiding: " + profile.avoid.join(", ") + "." }) : el("p", { class: "hint", text: "You did not tick any allergies." })
      ]);
      results.appendChild(summary);

      GROUPS.forEach(function (g) {
        var items = evaluated.filter(function (r) { return r.status === g[0]; });
        if (!items.length) { return; }
        var list = el("ul", { class: "result-list" });
        items.forEach(function (r) { list.appendChild(resultItem(r, g)); });
        var wrap = el("div", { class: "result-group" }, [
          el("h3", null, [el("span", { class: "badge " + g[2], text: items.length }), g[1]]),
          list
        ]);
        results.appendChild(wrap);
      });
      section.hidden = false;
      heading.focus();
      section.scrollIntoView({ behavior: REDUCED_MOTION ? "auto" : "smooth", block: "start" });
    }

    function resultItem(r, g) {
      var reasons = el("ul");
      r.reasons.forEach(function (t) { reasons.appendChild(el("li", { text: t })); });
      var actions = el("div", { class: "result-actions" });
      if (r.status === "review") {
        var btn = el("button", { type: "button", class: "btn btn--small" }, ["Request review"]);
        btn.addEventListener("click", function () {
          reviewText.textContent = "You asked for a professional to review " + r.product.name + ".";
          openDialog(review, btn);
        });
        actions.appendChild(btn);
      }
      actions.appendChild(el("a", { class: "btn btn--ghost btn--small", href: "products.html" }, ["See in catalogue"]));
      return el("li", { class: "result-item result-item--" + r.status }, [
        el("div", null, [
          el("h4", { text: r.product.name }),
          el("p", null, [el("span", { class: "badge " + g[2], text: g[3] }), " " + rand(r.product.price)]),
          reasons
        ]),
        actions
      ]);
    }

    renderHistory();
  }

  /* ---------------------------------------------------------------- 9. Validation helpers */
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var PHONE_RE = /^(\+27|0)[0-9]{9}$/;

  function fieldError(input, id, message) {
    var box = document.getElementById(id);
    if (message) {
      input.setAttribute("aria-invalid", "true");
      if (box) { box.textContent = message; box.classList.add("is-visible"); input.setAttribute("aria-describedby", id); }
    } else {
      input.removeAttribute("aria-invalid");
      if (box) { box.textContent = ""; box.classList.remove("is-visible"); }
    }
  }

  /* rules: [{input, errorId, check: fn(value) -> message or ""}]  Returns list of messages. */
  function runRules(rules) {
    var messages = [], first = null;
    rules.forEach(function (r) {
      var msg = r.check(r.input.value.trim());
      fieldError(r.input, r.errorId, msg);
      if (msg) { messages.push(msg); if (!first) { first = r.input; } }
    });
    return { messages: messages, first: first };
  }

  function showErrors(box, messages) {
    clear(box);
    box.className = "form-status form-status--error";
    box.appendChild(el("p", { text: "Please fix " + messages.length + (messages.length === 1 ? " problem" : " problems") + " below:" }));
    var ul = el("ul");
    messages.forEach(function (m) { ul.appendChild(el("li", { text: m })); });
    box.appendChild(ul);
  }
  function clearStatus(box) { clear(box); box.className = "form-status"; }

  /* live validation: re-check a field once the user has left it */
  function liveValidate(rules) {
    rules.forEach(function (r) {
      r.input.addEventListener("blur", function () { fieldError(r.input, r.errorId, r.check(r.input.value.trim())); });
      r.input.addEventListener("input", function () { if (r.input.getAttribute("aria-invalid")) { fieldError(r.input, r.errorId, r.check(r.input.value.trim())); } });
    });
  }

  var nameCheck = function (v) {
    if (!v) { return "Enter your full name."; }
    if (v.length < 2) { return "Your name must be at least 2 characters."; }
    if (/[<>]/.test(v)) { return "Your name cannot contain angle brackets."; }
    return "";
  };
  var emailCheck = function (v) {
    if (!v) { return "Enter your email address."; }
    if (!EMAIL_RE.test(v)) { return "Enter a valid email address, like name@example.com."; }
    return "";
  };

  /* Sends data by AJAX (fetch) when the form has a data-endpoint, otherwise
     simulates a short network delay. Resolves to {ok, simulated}. */
  function sendForm(form, payload) {
    var endpoint = form.getAttribute("data-endpoint");
    if (!endpoint) {
      return new Promise(function (resolve) { setTimeout(function () { resolve({ ok: true, simulated: true }); }, 500); });
    }
    return fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    }).then(function (res) { return { ok: res.ok, simulated: false }; });
  }

  function setBusy(form, busy) {
    var b = $('button[type="submit"]', form);
    b.disabled = busy;
    b.setAttribute("aria-disabled", String(busy));
    if (!b.dataset.label) { b.dataset.label = b.textContent; }
    b.textContent = busy ? "Sending..." : b.dataset.label;
  }

  /* ---------------------------------------------------------------- 10. Enquiry */
  function initEnquiry() {
    var form = $("#enquiry-form");
    if (!form) { return; }
    var errors = $("#enquiry-errors"), out = $("#enquiry-response");
    var f = { name: $("#enq-name"), email: $("#enq-email"), phone: $("#enq-phone"), product: $("#enq-product"), type: $("#enq-type"), msg: $("#enq-message"), trap: $("#enq-website") };
    var rules = [
      { input: f.name, errorId: "enq-name-error", check: nameCheck },
      { input: f.email, errorId: "enq-email-error", check: emailCheck },
      { input: f.phone, errorId: "enq-phone-error", check: function (v) {
          if (!v) { return ""; }
          return PHONE_RE.test(v.replace(/[\s-]/g, "")) ? "" : "Enter a South African number, like 0825550123 or +27825550123.";
        } },
      { input: f.product, errorId: "enq-product-error", check: function (v) { return v ? "" : "Choose the product you are asking about."; } },
      { input: f.type, errorId: "enq-type-error", check: function (v) { return v ? "" : "Choose what you would like to know."; } }
    ];
    liveValidate(rules);

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      clear(out);
      if (f.trap.value) { return; } /* spam trap filled in: silently ignore */
      var res = runRules(rules);
      if (res.messages.length) {
        showErrors(errors, res.messages);
        errors.focus();
        return;
      }
      clearStatus(errors);
      var payload = { name: f.name.value.trim(), email: f.email.value.trim(), phone: f.phone.value.trim(),
                      product: f.product.value, type: f.type.value, message: f.msg.value.trim() };
      setBusy(form, true);
      sendForm(form, payload).then(function (r) {
        setBusy(form, false);
        if (!r.ok) { throw new Error("bad response"); }
        showEnquiryResponse(payload);
        form.reset();
      }).catch(function () {
        setBusy(form, false);
        errors.className = "form-status form-status--error";
        errors.textContent = "Sorry, we could not send your enquiry. Please try again or use the contact page.";
      });
    });

    function showEnquiryResponse(d) {
      var p = PRODUCTS.filter(function (x) { return x.id === d.product; })[0];
      if (!p) { return; }
      var answer;
      if (d.type === "cost") { answer = p.name + " costs " + rand(p.price) + " per tub (" + p.servingSize + " serving). Prices are sample prices for this student project."; }
      else if (d.type === "availability") {
        var s = { "in-stock": "is in stock and ready to order.", "low-stock": "is low on stock, so order soon.", "out-of-stock": "is currently out of stock." }[p.stock];
        answer = p.name + " " + s;
      }
      else if (d.type === "ingredients") {
        answer = p.name + " contains: " + (p.contains.length ? p.contains.join(", ") : "none of the tracked allergens") +
          ". May contain: " + (p.mayContain.length ? p.mayContain.join(", ") : "nothing listed") + ". Full ingredients: " + p.ingredients.join(", ") + ".";
      }
      else {
        answer = p.reviewFor.length ?
          p.name + " is flagged for professional review if you have " + p.reviewFor.map(function (r) { return label(DATA.RISK_FACTORS, r); }).join(", ") + ". Please speak to a doctor, dietitian or pharmacist first."
          : p.name + " has no professional-review flag, but always check the label against your own situation.";
      }
      clear(out);
      var panel = el("section", { class: "response-panel", tabindex: "-1", "aria-labelledby": "enq-resp-title" }, [
        el("h2", { id: "enq-resp-title", text: "Thanks, " + d.name.split(" ")[0] + "!" }),
        el("p", { text: answer }),
        el("dl", null, [
          el("dt", { text: "Product" }), el("dd", { text: p.name }),
          el("dt", { text: "Price" }), el("dd", { text: rand(p.price) }),
          el("dt", { text: "Availability" }), el("dd", { text: label(DATA.STOCK, p.stock) }),
          el("dt", { text: "Reply to" }), el("dd", { text: d.email })
        ]),
        el("p", { class: "hint", text: "This answer is generated in your browser from sample data. Nothing was stored." })
      ]);
      out.appendChild(panel);
      panel.focus();
      panel.scrollIntoView({ behavior: REDUCED_MOTION ? "auto" : "smooth", block: "nearest" });
    }
  }

  /* ---------------------------------------------------------------- 11. Contact */
  function initContact() {
    var form = $("#contact-form");
    if (!form) { return; }
    var errors = $("#contact-errors"), out = $("#contact-preview");
    var f = { name: $("#con-name"), email: $("#con-email"), subject: $("#con-subject"), msg: $("#con-message"), trap: $("#con-website") };
    var rules = [
      { input: f.name, errorId: "con-name-error", check: nameCheck },
      { input: f.email, errorId: "con-email-error", check: emailCheck },
      { input: f.subject, errorId: "con-subject-error", check: function (v) { return v ? "" : "Choose a subject."; } },
      { input: f.msg, errorId: "con-message-error", check: function (v) {
          if (!v) { return "Write a message."; }
          return v.length < 10 ? "Your message must be at least 10 characters." : "";
        } }
    ];
    liveValidate(rules);

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      clear(out);
      if (f.trap.value) { return; }
      var res = runRules(rules);
      if (res.messages.length) { showErrors(errors, res.messages); errors.focus(); return; }
      clearStatus(errors);

      var d = { name: f.name.value.trim(), email: f.email.value.trim(), subject: f.subject.value, message: f.msg.value.trim() };
      var body = "Name: " + d.name + "\nEmail: " + d.email + "\n\n" + d.message;
      var mailto = "mailto:" + CONTACT_RECIPIENT + "?subject=" + encodeURIComponent("Website enquiry: " + d.subject) +
                   "&body=" + encodeURIComponent(body);

      setBusy(form, true);
      sendForm(form, d).then(function () {
        setBusy(form, false);
        clear(out);
        var panel = el("section", { class: "response-panel", tabindex: "-1", "aria-labelledby": "con-resp-title" }, [
          el("h2", { id: "con-resp-title", text: "Your email is ready" }),
          el("p", { text: "We compiled your message into an email to " + CONTACT_RECIPIENT + ". Check it below, then open it in your email app to send." }),
          el("div", { class: "email-preview", text: "To: " + CONTACT_RECIPIENT + "\nSubject: Website enquiry: " + d.subject + "\n\n" + body }),
          el("div", { class: "btn-row" }, [
            el("a", { class: "btn", href: mailto }, ["Open in my email app"])
          ])
        ]);
        out.appendChild(panel);
        panel.focus();
        form.reset();
      }).catch(function () {
        setBusy(form, false);
        errors.className = "form-status form-status--error";
        errors.textContent = "Sorry, something went wrong. Please try again, or email us directly.";
      });
    });
  }

  /* ---------------------------------------------------------------- 12. Map */
  var LOCATIONS = [
    { name: "Smart Supplement Safety - Sandton", address: "12 Rivonia Road, Sandton, Johannesburg, 2196", lat: -26.1076, lng: 28.0567 },
    { name: "Smart Supplement Safety - Rosebank", address: "45 Oxford Road, Rosebank, Johannesburg, 2196", lat: -26.1467, lng: 28.0436 }
  ];

  function initMap() {
    var box = $("#map");
    if (!box) { return; }
    if (typeof window.L === "undefined") {
      box.appendChild(el("p", { class: "empty-state", text: "The map could not load. Our addresses are listed beside it." }));
      return;
    }
    var L = window.L;
    var map = L.map(box, { scrollWheelZoom: false }).setView([-26.127, 28.05], 12);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
      subdomains: "abcd",
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" rel="noopener noreferrer">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions" rel="noopener noreferrer">CARTO</a>'
    }).addTo(map);

    var markers = LOCATIONS.map(function (loc) {
      var icon = L.divIcon({ className: "", html: '<span class="map-pin"></span>', iconSize: [0, 0] });
      var m = L.marker([loc.lat, loc.lng], { icon: icon, title: loc.name, keyboard: true }).addTo(map);
      var pop = el("div", null, [el("strong", { text: loc.name }), el("br"), loc.address]);
      m.bindPopup(pop);
      return m;
    });
    map.fitBounds(L.featureGroup(markers).getBounds().pad(0.3));

    /* "Show on map" buttons beside each address */
    $$(".location", $("#location-list")).forEach(function (li, i) {
      var b = el("button", { type: "button", class: "btn btn--ghost btn--small" }, ["Show on map"]);
      b.addEventListener("click", function () {
        map.setView([LOCATIONS[i].lat, LOCATIONS[i].lng], 16, { animate: !REDUCED_MOTION });
        markers[i].openPopup();
        box.scrollIntoView({ behavior: REDUCED_MOTION ? "auto" : "smooth", block: "nearest" });
      });
      li.appendChild(b);
    });
    /* scroll-wheel zoom only after the map has been clicked, so page scrolling is not hijacked */
    map.on("focus", function () { map.scrollWheelZoom.enable(); });
    map.on("blur", function () { map.scrollWheelZoom.disable(); });
  }

  /* ---------------------------------------------------------------- start */
  function init() {
    initNav();
    initAccordions();
    initTabs();
    initDialogs();
    initCatalogue();
    initScreening();
    initEnquiry();
    initContact();
    initMap();
    initReveal();
  }

  if (document.readyState === "loading") { document.addEventListener("DOMContentLoaded", init); } else { init(); }
})();
