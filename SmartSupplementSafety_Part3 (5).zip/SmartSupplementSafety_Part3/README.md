# Smart Supplement Safety

**WEDE5020 Portfolio of Evidence** - Siyanda Khathide (ST10532358)

A front-end-only website (HTML, CSS, vanilla JavaScript) that lets gym clients screen a sample supplement catalogue against their fitness goal, allergies and health situation. All "back-end" behaviour (screening, enquiry answers, review requests) is simulated in the browser; there is no server or database. Product data lives in `js/products.js`.

> Live site: _add your Netlify / GitHub Pages link here_
> Repository: _add your GitHub link here_

## Pages
| Page | Purpose |
|---|---|
| `index.html` | Home: hero, how it works, label legend, FAQ accordion |
| `about.html` | Mission, vision, how screening works (tabs) |
| `products.html` | Catalogue: search, filter, sort, details modal, image lightbox |
| `screening.html` | Allergy / goal screening, grouped results, saved history |
| `enquiry.html` | Validated enquiry form with instant price / stock / ingredient answer |
| `contact.html` | Leaflet map (2 locations) and validated contact form that compiles an email |

## Folder structure
```
css/style.css          external stylesheet (Part 2)
js/script.js           all interactivity (Part 3)
js/products.js         sample product data
js/vendor/leaflet/     Leaflet 1.9.4 (self-hosted, BSD-2)
images/                product + hero images (PNG and WebP, 400/800/480/960 px)
screenshots/           desktop, tablet, mobile screenshots
robots.txt, sitemap.xml, _headers
```

## Part 2 - CSS summary
- One external stylesheet, mobile-first, CSS custom properties for colour, type and spacing.
- Typography: Atkinson Hyperlegible (Google Fonts) with system fallbacks; rem type scale.
- Layout: Flexbox (header, buttons, rows) and Grid (cards, forms, footer, catalogue `auto-fill`).
- Units: rem / em / % / fr; media queries in `em` at 40em (tablet) and 64em (desktop).
- States: `:hover`, `:focus-visible`, `:active` on links, buttons, cards, inputs, tabs.
- Responsive images: `<picture>` with WebP + PNG, `srcset` and `sizes`, width/height set, lazy loading.
- Accessibility: skip link, visible focus, colour contrast, `prefers-reduced-motion`.

### Screenshots
| | Desktop | Tablet | Mobile |
|---|---|---|---|
| Home | ![](screenshots/index-desktop.png) | ![](screenshots/index-tablet.png) | ![](screenshots/index-mobile.png) |
| Catalogue | ![](screenshots/catalogue-desktop.png) | ![](screenshots/catalogue-tablet.png) | ![](screenshots/catalogue-mobile.png) |
| Screening | ![](screenshots/screening-desktop.png) | ![](screenshots/screening-tablet.png) | ![](screenshots/screening-mobile.png) |
| Contact | ![](screenshots/contact-desktop.png) | ![](screenshots/contact-tablet.png) | ![](screenshots/contact-mobile.png) |

(Map tiles show blank in screenshots taken offline.)

## Part 3 - JavaScript summary
| Requirement | Where |
|---|---|
| Accordion | FAQ on `index.html` |
| Tabs | `about.html` |
| Modals | Product details, review request (native `<dialog>`) |
| Gallery + lightbox | Catalogue images, previous / next, arrow keys |
| Interactive map (2+ locations) | `contact.html`, Leaflet + CARTO dark tiles (OpenStreetMap data) |
| Animations | Scroll reveal, card hover, dialog pop-in (disabled for reduced motion) |
| DOM manipulation / dynamic content | Catalogue, results and history are built from `SSS_DATA` |
| Search, filter, sort | Catalogue toolbar |
| Form validation with messages | Enquiry and contact (name, email, SA phone, selects, message length), honeypot field |
| AJAX | `fetch` POST to `data-endpoint` on the form; simulated when empty |
| Enquiry response | Price / stock / ingredients / suitability answer shown after validation |
| Contact -> email | Compiles a `mailto:` link with the message to the stated recipient |

### Screening rules
1. Declared allergy found in a product's *contains* list -> **Avoid**
2. Else a health factor matches the product's *reviewFor* list -> **Needs professional review**
3. Else a declared allergy in *mayContain* -> **Caution**
4. Else goal matches -> **Potential match**; otherwise **No conflict**

A goal is required. These are demonstration rules, not medical rules.

## SEO
Unique `<title>` and meta description per page, keywords, one `<h1>` per page with ordered headings, descriptive image file names and alt text, internal links on every page, JSON-LD business data, `robots.txt`, `sitemap.xml`, lazy loading and responsive images for speed.

## Security
No inline scripts or handlers, user input only inserted with `textContent`, honeypot, `rel="noopener noreferrer"`, referrer policy, and security headers / CSP via `_headers` on Netlify.

## Deployment
**Netlify (drag and drop):** zip or drag the project folder to app.netlify.com/drop. **GitHub Pages:** push to GitHub, Settings -> Pages -> deploy from `main` / root. Afterwards replace `YOUR-SITE-NAME.netlify.app` in `robots.txt` and `sitemap.xml` with your real address, and change `CONTACT_RECIPIENT` in `js/script.js` to a real email.

## Testing
Automated browser test (Playwright, Chromium) over the file:// build: accordion, tabs, search, filters, sort, details modal, lightbox, screening results and history, enquiry and contact validation + responses, mailto encoding, map markers, mobile menu, no horizontal scroll, zero console errors. Manual checks at 1280, 768 and 390 px widths.

## Changelog
- **Part 1** - Six plain HTML pages, structure, README, proposal.
- **Part 2** - Added `css/style.css`: tokens, reset, typography, header/nav, hero, cards, forms, catalogue grid, dialogs, footer, hover/focus/active states, responsive breakpoints, picture/srcset images. Pages regenerated with shared header/footer, skip link and `aria-current`.
- **Part 3** - Added `js/script.js` and `js/products.js`: navigation toggle, accordion, tabs, catalogue search/filter/sort, modal, lightbox, screening engine and history, validated enquiry and contact forms with AJAX, Leaflet map, scroll animation. Added `robots.txt`, `sitemap.xml`, `_headers`, JSON-LD, meta tags.
- Fixed: sample product label text overflow; replaced inline styles/handlers so the CSP works.

## References
_Add Harvard-style references here (e.g. Leaflet, OpenStreetMap, Atkinson Hyperlegible, MDN pages you used)._

## Disclaimer
Sample data for a student project. Smart Supplement Safety does not diagnose medical conditions or replace professional advice.
